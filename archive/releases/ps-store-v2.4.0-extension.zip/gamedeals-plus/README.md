# GameDeals+ for PS Store - Extension

## Load in Chrome (Developer Mode)

1. Open `chrome://extensions`
2. Enable Developer mode (top right)
3. Click Load unpacked
4. Select this folder
5. Go to store.playstation.com

## Disclaimer

This extension is not affiliated with Sony Interactive Entertainment or PlayStation.
